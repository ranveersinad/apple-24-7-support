package io.appmetrica.analytics.adrevenue.admob.v23.impl;

public class Constants {

    public static final String MODULE_ID = "ad-revenue-admob-v23";
    public static final String LIBRARY_MAIN_CLASS = "com.google.android.gms.ads.AdView";
}
