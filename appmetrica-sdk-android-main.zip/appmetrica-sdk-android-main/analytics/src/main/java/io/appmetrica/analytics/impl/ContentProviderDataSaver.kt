package io.appmetrica.analytics.impl

internal interface ContentProviderDataSaver<T> : Function1<T, Boolean>
