package io.appmetrica.analytics.impl.component;

import androidx.annotation.NonNull;

public interface IDispatcherComponent {

    void updateConfig(@NonNull CommonArguments arguments);
}
