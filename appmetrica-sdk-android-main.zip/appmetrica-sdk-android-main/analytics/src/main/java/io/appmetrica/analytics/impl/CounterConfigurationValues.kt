package io.appmetrica.analytics.impl

object CounterConfigurationValues {

    // Old default API Key for backward compatibility
    const val DEFAULT_UNDEFINED_API_KEY = "-1"
}
