package io.appmetrica.analytics.impl.component;

import androidx.annotation.NonNull;

public class CommutationComponentId extends ComponentId {

    public CommutationComponentId(@NonNull final String packageName) {
        super(packageName, null);
    }

}
