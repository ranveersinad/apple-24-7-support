package io.appmetrica.analytics.impl;

public interface IServerTimeOffsetProvider {

    long getServerTimeOffsetSeconds();
}
