package io.appmetrica.analytics.impl.crash;

public class AppMetricaThrowable extends Throwable {
}
