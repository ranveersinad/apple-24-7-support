package io.appmetrica.analytics.impl

interface MainReporterInitializer {

    fun initialize(): MainReporter
}
