package io.appmetrica.analytics.impl.billing;

public class Constants {
    public static final String SEND_FREQUENCY_SECONDS = "send_frequency_seconds";
    public static final String FIRST_COLLECTING_INAPP_MAX_AGE_SECONDS = "first_collecting_inapp_max_age_seconds";
}
