package io.appmetrica.analytics.impl.attribution

enum class ExternalAttributionType {
    UNKNOWN,
    APPSFLYER,
    ADJUST,
    KOCHAVA,
    TENJIN,
    AIRBRIDGE,
    SINGULAR,
}
