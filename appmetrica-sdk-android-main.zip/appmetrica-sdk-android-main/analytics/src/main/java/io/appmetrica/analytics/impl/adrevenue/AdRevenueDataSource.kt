package io.appmetrica.analytics.impl.adrevenue

enum class AdRevenueDataSource(
    val value: String
) {

    AUTOCOLLECTED("autocollected"),
    MANUAL("manual")
}
