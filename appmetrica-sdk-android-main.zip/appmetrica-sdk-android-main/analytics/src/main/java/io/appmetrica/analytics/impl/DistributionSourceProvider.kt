package io.appmetrica.analytics.impl

internal interface DistributionSourceProvider {

    val source: DistributionSource
}
