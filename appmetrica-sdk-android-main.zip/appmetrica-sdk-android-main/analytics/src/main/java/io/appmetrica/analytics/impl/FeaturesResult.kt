package io.appmetrica.analytics.impl

class FeaturesResult(
    val libSslEnabled: Boolean?
)
