package io.appmetrica.analytics.impl;

public class Limits {

    public static final int EVENT_VALUE_FOR_LOGS_LIMIT = 500;
}
