package io.appmetrica.analytics.adrevenue.ironsource.v7.impl;

public class Constants {

    public static final String MODULE_ID = "ad-revenue-ironsource-v7";
    public static final String LIBRARY_MAIN_CLASS = "com.ironsource.mediationsdk.IronSource";
}
