package io.appmetrica.analytics.adrevenue.fyber.v3.impl;

public class Constants {

    public static final String MODULE_ID = "ad-revenue-fyber-v3";
    public static final String LIBRARY_MAIN_CLASS = "com.fyber.fairbid.ads.Interstitial";
}
